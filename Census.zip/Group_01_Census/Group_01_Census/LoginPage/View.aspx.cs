﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace Group_01_Census.WebPage
{
    public partial class View : System.Web.UI.Page
    {
        

        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            if (Session["FullName"] != null)
            {
                menushow();
            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }

        }
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("~/WebPage/Login.aspx");
        }
        private void menushow()
        {
            string name = (Session["FullName"]).ToString();
            string role = (Session["Role"]).ToString();
            lblwelcome.Text = (role + "| Welcome : " + name);

            if (role == "Manager")
            {
                UserMenu.Visible = false;
                btndelmsg.Visible = false;
                btnDeleteRecord.Visible = false;
                BtnUser.Visible = false;
                btnNews.Visible = false;


            }
            else if (role == "User")
            {
                BtnMsg.Visible = false;
                btnNews.Visible = false;
                UserMenu.Visible = false;
                searchpart.Visible = false;
                BtnUser.Visible = false;
                btnDeleteRecord.Visible = false;
            }
            else
            {

            }
        }

        //--------public part ------------------------------------------------------
        protected void BtnShow_Click(object sender, EventArgs e)
        {
            BindPublic();
            UserDivShow.Visible = false;
            MessageDivShow.Visible = false;
            NewsDivShow.Visible = false;
            theDiv.Visible = false;
            Newsdiv.Visible = false;
            pubsearch();


        }

        protected void btnDistSearch_Click(object sender, EventArgs e)
        {
            if ((TxtBxSerch.Text) != "")
            {
            SqlDataAdapter adapt;
            DataTable dt;
            SqlConnection conn = new SqlConnection(conString);
            
            conn.Open();
            string division = (Session["Division"]).ToString();
            string role = (Session["Role"]).ToString();
            
                if (role == "Manager")
                {
                    adapt = new SqlDataAdapter("select * from Registration where Name like '" + TxtBxSerch.Text + "%' or Father like '" + TxtBxSerch.Text + "%' or Mother like '" + TxtBxSerch.Text + "%' or Upazila like '" + TxtBxSerch.Text + "%' or Gender like '" + TxtBxSerch.Text + "%'", conn);
                    dt = new DataTable();
                    adapt.Fill(dt);
                    conn.Close();
                    lvlCount.Text = (dt.Rows.Count).ToString();
                    if (dt.Rows.Count > 0)
                    {
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                        lvlsumtotal.Text = total.ToString();
                        GridView1.Visible = true;
                        DivGridViewPublic.Visible = false;
                        theDiv.Visible = false;
                        divlblpub.Visible = true;
                        divlblmsg.Visible = false;
                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.Text = "No Records Found";
                        GridView1.Visible = false;
                        DivGridViewPublic.Visible = false;
                        theDiv.Visible = false;
                        divlblpub.Visible = false;
                        divlblmsg.Visible = false;
                    }
                }
                else
                {
                    adapt = new SqlDataAdapter("select * from Registration where Name like '" + TxtBxSerch.Text + "%' or Father like '" + TxtBxSerch.Text + "%' or Mother like '" + TxtBxSerch.Text + "%' or Upazila like '" + TxtBxSerch.Text + "%' or Gender like '" + TxtBxSerch.Text + "%'", conn);
                    dt = new DataTable();
                    adapt.Fill(dt);
                    conn.Close();
                    lvlCount.Text = (dt.Rows.Count).ToString();
                    if (dt.Rows.Count > 0)
                    {
                        GridViewPublic.DataSource = dt;
                        GridViewPublic.DataBind();
                        GridViewPublic.Visible = true;
                        int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                        lvlsumtotal.Text = total.ToString();
                        DivGridViewPublic.Visible = true;
                        GridView1.Visible = false;
                        theDiv.Visible = false;
                        divlblpub.Visible = true;
                        divlblmsg.Visible = false;
                        btnDeleteRecord.Visible = true;
                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.Text = "No Records Found";
                        GridViewPublic.Visible = false;
                        GridView1.Visible = false;
                        DivGridViewPublic.Visible = false;
                        theDiv.Visible = false;
                        divlblpub.Visible = false;
                        divlblmsg.Visible = false;
                        btnDeleteRecord.Visible = false;
                    }
                }


               
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Search Box is Empty";
                GridView1.Visible = false;
                DivGridViewPublic.Visible = false;
                theDiv.Visible = false;
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
            }
        }
        protected void btnPubSearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(conString);
            conn.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from Registration where District = '" + ddlSearch.SelectedItem.Text + "'", conn);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            conn.Close();
            lvlCount.Text = (dt.Rows.Count).ToString();
            string role = (Session["Role"]).ToString();
            if (dt.Rows.Count > 0)
            {
                if (role == "Admin")
                {
                    GridViewPublic.DataSource = dt;
                    GridViewPublic.DataBind();
                    GridViewPublic.Visible = true;
                    int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                    lvlsumtotal.Text = total.ToString();
                    GridView1.Visible = false;
                    DivGridViewPublic.Visible = true;
                    theDiv.Visible = false;
                    divlblpub.Visible = true;
                    divlblmsg.Visible = false;
                    btnDeleteRecord.Visible = true;
                }
               else if (role == "Manager")
                {
                    GridViewPublic.DataSource = dt;
                    GridViewPublic.DataBind();
                    GridViewPublic.Visible = true;
                    int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                    lvlsumtotal.Text = total.ToString();
                    GridView1.Visible = false;
                    DivGridViewPublic.Visible = true;
                    theDiv.Visible = false;
                    divlblpub.Visible = true;
                    divlblmsg.Visible = false;
                    btnDeleteRecord.Visible = false;
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                    lvlsumtotal.Text = total.ToString();
                    GridView1.Visible = true;
                    DivGridViewPublic.Visible = false;
                    theDiv.Visible = false;
                    divlblpub.Visible = true;
                    divlblmsg.Visible = false;
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "No Records Found";
                GridViewPublic.Visible = false;
                GridView1.Visible = false;
                DivGridViewPublic.Visible = false;
                theDiv.Visible = false;
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
                btnDeleteRecord.Visible = false;
            }
        }
        SqlCommand cmd;
        private void pubsearch()
        {
            
            SqlConnection conn = new SqlConnection(conString);
            string division = (Session["Division"]).ToString();
            string role = (Session["Role"]).ToString();
            if (role == "User" || role == "Manager")
            {
                cmd = new SqlCommand("select District_Name from District where Division_ID = (select Division_ID from Division where Division_Name='" + division + "')", conn);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                ddlSearch.DataSource = dr;
                ddlSearch.DataTextField = "District_Name";
                ddlSearch.DataBind();
                ddlSearch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select District--", "0"));
                conn.Close();
            }
            else
            {
                cmd = new SqlCommand("select District from Registration group by District", conn);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                ddlSearch.DataSource = dr;
                ddlSearch.DataTextField = "District";
                ddlSearch.DataBind();
                ddlSearch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select District--", "0"));
                conn.Close();
            }
            
            
        }

        private void BindPublic()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(conString);
            try{
                string role = (Session["Role"]).ToString();
                string division = (Session["Division"]).ToString();
                if (role == "Manager")
                {
                          SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Registration where Division ='" + division +"'", con);
                          con.Open();
                           adapt.Fill(dt);
                           con.Close();            
                          lvlCount.Text = (dt.Rows.Count).ToString();
                      if (dt.Rows.Count > 0)
                      {
                          GridViewPublic.DataSource = dt;
                          GridViewPublic.DataBind();
                          GridViewPublic.Visible = true;
                          int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                          lvlsumtotal.Text = total.ToString();
                          PublicDivShow.Visible = true;
                          divlblpub.Visible = true;
                          divlblmsg.Visible = false;
                      }
                      else
                      {
                          lblmsg.Visible = true;
                          lblmsg.Text = "No Records Found";
                          divlblpub.Visible = false;
                          divlblmsg.Visible = false;
                          GridViewPublic.Visible = false;
                      }
                }
               else if (role == "User")
                {
                    SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Registration where Division ='" + division + "'", con);
                    con.Open();
                    adapt.Fill(dt);
                    con.Close();
                    lvlCount.Text = (dt.Rows.Count).ToString();
                    if (dt.Rows.Count > 0)
                    {
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        GridView1.Visible = true;
                        int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                        lvlsumtotal.Text = total.ToString();
                        PublicDivShow.Visible = true;
                        divlblpub.Visible = true;
                        divlblmsg.Visible = false;
                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.Text = "No Records Found";
                        GridView1.Visible = false;
                        divlblpub.Visible = false;
                        divlblmsg.Visible = false;
                    }
                }

                else { 
            
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Registration", con);
            con.Open();
            adapt.Fill(dt);
            con.Close();            
            lvlCount.Text = (dt.Rows.Count).ToString();
                if (dt.Rows.Count > 0)
                {
                    GridViewPublic.DataSource = dt;
                    GridViewPublic.DataBind();
                    GridViewPublic.Visible = true;
                    int total = dt.AsEnumerable().Sum(row => row.Field<int>("Number"));
                    lvlsumtotal.Text = total.ToString();
                    PublicDivShow.Visible = true;
                    divlblpub.Visible = true;
                    divlblmsg.Visible = false;
                    btnDeleteRecord.Visible = true;
                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No Records Found";
                    GridView1.Visible = false;
                    GridViewPublic.Visible = false;
                    divlblpub.Visible = false;
                    divlblmsg.Visible = false;
                    btnDeleteRecord.Visible = false;
                }
                }

            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
            }
            
        }
        protected void DeleteRecord(int id)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("delete from Registration where Public_ID=@ID", con);
            com.Parameters.AddWithValue("@ID", id);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            BindPublic();
        }

        protected void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            
            foreach (GridViewRow grow in GridViewPublic.Rows)
            {
                CheckBox chkdel = (CheckBox)grow.FindControl("chkDel"); 
                if (chkdel.Checked)
                {
                    int id = Convert.ToInt32(grow.Cells[1].Text); 
                    DeleteRecord(id);
                }
            }
        }

        protected void btnDetailsin_Click(object sender, EventArgs e)
        {
            try { 
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string uid = GridView1.Rows[row.RowIndex].Cells[0].Text;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM Registration where Public_ID='" + Convert.ToInt32(uid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                lblName.Text = reader["Name"].ToString();
                lblFather.Text = reader["Father"].ToString();
                lblMother.Text = reader["Mother"].ToString();
                lblGender.Text = reader["Gender"].ToString();
                lblMobile.Text = reader["Mobile"].ToString();
                lblIDNum.Text = reader["NID"].ToString();
                lblFamilyNum.Text = reader["Number"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["DOB"].ToString());
                lblDOB.Text = Birth.ToString("dd/MMM/yyyy");
                lblVill.Text = reader["Address"].ToString();
                lblUpa.Text = reader["Upazila"].ToString();
                lblDist.Text = reader["District"].ToString();
                lblDiv.Text = reader["Division"].ToString();
                reader.Close();
                con.Close();
                theDiv.Visible = true;
                Lblmsghide();
                Lblshow();
            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;

            }
        }

        protected void btnDetails_Click(object sender, EventArgs e)
        {
            try{ 
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            string uid = GridViewPublic.Rows[row.RowIndex].Cells[1].Text;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select * FROM Registration where Public_ID='" + Convert.ToInt32(uid) +"'", con);
            SqlDataReader reader = com.ExecuteReader();
            reader.Read();
            lblName.Text = reader["Name"].ToString();
            lblFather.Text = reader["Father"].ToString();
            lblMother.Text = reader["Mother"].ToString();
            lblGender.Text = reader["Gender"].ToString();
            lblMobile.Text = reader["Mobile"].ToString();
            lblIDNum.Text = reader["NID"].ToString();
            lblFamilyNum.Text = reader["Number"].ToString();
            DateTime Birth = Convert.ToDateTime(reader["DOB"].ToString());
            lblDOB.Text = Birth.ToString("dd/MMM/yyyy");
            lblVill.Text = reader["Address"].ToString();
            lblUpa.Text = reader["Upazila"].ToString();
            lblDist.Text = reader["District"].ToString();
            lblDiv.Text = reader["Division"].ToString();
            reader.Close();
            con.Close();
            theDiv.Visible = true;
            Lblmsghide();
            Lblshow();
            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
                
            }
        }
    
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Button btnn = (Button)sender;
            GridViewRow row = (GridViewRow)btnn.NamingContainer;
            string uid = GridViewPublic.Rows[row.RowIndex].Cells[1].Text;
            string url = "Update.aspx?Id=" + uid;
            Response.Redirect(url);
        }

        private void Lblhide()
        {
            lblDist.Visible = false;
            lblDiv.Visible = false;
            lblDOB.Visible = false;
            lblFamilyNum.Visible = false;
            lblFather.Visible = false;
            lblGender.Visible = false;
            lblIDNum.Visible = false;
            lblMobile.Visible = false;
            lblMother.Visible = false;
            lblName.Visible = false;
            lblUpa.Visible = false;
            lblVill.Visible = false;
            Label10.Visible = false;
            Label11.Visible = false;
            Label12.Visible = false;
            Label13.Visible = false;
            Label14.Visible = false;
            Label15.Visible = false;
            Label16.Visible = false;
            Label2.Visible = false;
            Label6.Visible = false;
            Label7.Visible = false;
            Label8.Visible = false;
            Label9.Visible = false;
            msghi.Visible = false;
        }
        private void Lblshow()
        {
            lblDist.Visible = true;
            lblDiv.Visible = true;
            lblDOB.Visible = true;
            lblFamilyNum.Visible = true;
            lblFather.Visible = true;
            lblGender.Visible = true;
            lblIDNum.Visible = true;
            lblMobile.Visible = true;
            lblMother.Visible = true;
            lblName.Visible = true;
            lblUpa.Visible = true;
            lblVill.Visible = true;
            Label10.Visible = true;
            Label11.Visible = true;
            Label12.Visible = true;
            Label13.Visible = true;
            Label14.Visible = true;
            Label15.Visible = true;
            Label16.Visible = true;
            Label2.Visible = true;
            Label6.Visible = true;
            Label7.Visible = true;
            Label8.Visible = true;
            Label9.Visible = true;
            msghi.Visible = true;
        }
     

        //------------------------ message part-------------------------------------------------
        private void Lblmsghide()
        {
            lblmdiv.Visible = false;
            lblmemail.Visible = false;
            lblmmsg.Visible = false;
            lblmname.Visible = false;
            lblmsuj.Visible = false;
            lblmtime.Visible = false;
            GridViewNews.Visible = false;
            Newsdiv.Visible = false;
        }
        private void Lblmsgshow()
        {
            lblmdiv.Visible = true;
            lblmemail.Visible = true;
            lblmmsg.Visible = true;
            lblmname.Visible = true;
            lblmsuj.Visible = true;
            lblmtime.Visible = true;
            lblFather.Visible = true;
            lblMother.Visible = false;
            lblGender.Visible = true;
            lblIDNum.Visible = true;
            lblName.Visible = true;
            lblMobile.Visible = true;
            lblFamilyNum.Visible = true;
            msghi.Visible = false;
        }


        protected void BtnMsg_Click(object sender, EventArgs e)
        {

            PublicDivShow.Visible = false;
            
            UserDivShow.Visible = false;
            NewsDivShow.Visible = false;
            theDiv.Visible = false;
            Newsdiv.Visible = false;
            BindMessage();

        }
        private void BindMessage()
        {
            try{
                string role = (Session["Role"]).ToString();
            SqlConnection con = new SqlConnection(conString);
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM Contact", con);
            con.Open();
            adapt.Fill(dt);
            con.Close();
            lblnumbercount.Text = (dt.Rows.Count).ToString();
             if (dt.Rows.Count > 0)
                {
                    if (role == "Admin")
                    {
                        GridViewMessage.DataSource = dt;
                        GridViewMessage.DataBind();
                        GridViewMessage.Visible = true;
                        MessageDivShow.Visible = true;
                        divlblpub.Visible = false;
                        divlblmsg.Visible = true;
                        btndelmsg.Visible = true;
                    }
                    else
                    {
                        GridViewMessage.DataSource = dt;
                        GridViewMessage.DataBind();
                        GridViewMessage.Visible = true;
                        MessageDivShow.Visible = true;
                        divlblpub.Visible = false;
                        divlblmsg.Visible = true;
                        btndelmsg.Visible = false;
                    }
                }
                else
                {
                    lblmsg.Visible = true;
                    GridViewMessage.Visible = false;
                    lblmsg.Text = "No Records Found";
                    divlblpub.Visible = false;
                    divlblmsg.Visible = false;
                    btndelmsg.Visible = false;
                }

            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
            }
            
        
                        
        }
        protected void DeleteMessage(int id)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("delete from Contact where ID=@ID", con);
            com.Parameters.AddWithValue("@ID", id);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            BindMessage();
        }

        protected void btndelmsg_Click(object sender, EventArgs e)
        {

            foreach (GridViewRow mrow in GridViewMessage.Rows)
            {
                CheckBox chkdel = (CheckBox)mrow.FindControl("chkDel");
                if (chkdel.Checked)
                {
                    int id = Convert.ToInt32(mrow.Cells[1].Text);
                    DeleteMessage(id);
                }
            }
            
        }

        protected void btnmsgDetails_Click(object sender, EventArgs e)
        {
            
            try{
                Lblhide();
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            string mid = GridViewMessage.Rows[row.RowIndex].Cells[1].Text;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select * FROM Contact where ID='" + Convert.ToInt32(mid) + "'", con);
            SqlDataReader reader = com.ExecuteReader();
            reader.Read();
            lblName.Text = reader["Name"].ToString();
            lblFather.Text = reader["Email"].ToString();
            lblGender.Text = reader["Subject"].ToString();
            lblMobile.Text = reader["Division"].ToString();
            lblIDNum.Text = reader["Message"].ToString();
            DateTime Birth = Convert.ToDateTime(reader["Time"].ToString());
            lblFamilyNum.Text = Birth.ToString("dd/MMM/yy hh:mm:ss tt");           
            reader.Close();
            con.Close();
            theDiv.Visible = true;
            Lblmsgshow();

            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
                
            }
            
        }
    


        //------------user part ------------------------------------------------

        private void getUser()
        {

            try
            {

                SqlConnection con = new SqlConnection(conString);
                DataTable dt = new DataTable();
                SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM UserInfo", con);
                con.Open();
                adapt.Fill(dt);
                con.Close();
                lblnumbercount.Text = (dt.Rows.Count).ToString();
                if (dt.Rows.Count > 0)
                {
                    GdVwUser.DataSource = dt;
                    GdVwUser.DataBind();
                    GdVwUser.Visible = true;
                    UserDivShow.Visible = true;
                    divlblpub.Visible = false;
                    divlblmsg.Visible = true;
                }
                else
                {
                    GdVwUser.Visible = false;
                    lblmsg.Visible = true;
                    lblmsg.Text = "No Records Found";
                    divlblpub.Visible = false;
                    divlblmsg.Visible = false;
                }

            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
                
            }
        }
        protected void GdVwUser_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GdVwUser.EditIndex = e.NewEditIndex;
            getUser();
        }
        protected void GdVwUser_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {

                int userid = Convert.ToInt32(GdVwUser.DataKeys[e.RowIndex].Value.ToString());
                GridViewRow row = (GridViewRow)GdVwUser.Rows[e.RowIndex];

                Label lblID = (Label)row.FindControl("lblID");
                TextBox textName = (TextBox)row.Cells[1].Controls[0];
                TextBox textUId = (TextBox)row.Cells[2].Controls[0];
                TextBox textPassword = (TextBox)row.Cells[3].Controls[0];
                TextBox textdate = (TextBox)row.Cells[4].Controls[0];
                TextBox textrole = (TextBox)row.Cells[5].Controls[0];
                TextBox textmobile = (TextBox)row.Cells[6].Controls[0];
                TextBox textaddress = (TextBox)row.Cells[7].Controls[0];
                TextBox textdivision = (TextBox)row.Cells[8].Controls[0];

                string role = textrole.Text;
                SqlConnection con = new SqlConnection(conString);
                con = new SqlConnection(conString);
                con.Open();
                SqlCommand divname = new SqlCommand("SELECT COUNT(*) FROM Division where Division_Name='" + textdivision.Text + "'", con);
                int divnameExist = (int)divname.ExecuteScalar();
                try{
                SqlCommand cmd = new SqlCommand("update UserInfo set UserName='" + textUId.Text.ToLower() + "' where User_ID='" + userid + "'", con);
                    cmd.ExecuteNonQuery();
                    if ((divnameExist > 0) && (role == "Admin" || role == "Manager" || role == "User"))
                    {

                        SqlCommand cdm = new SqlCommand("update UserInfo set FullName='" + textName.Text + "',Password='" + textPassword.Text + "',Date='" + textdate.Text + "',Role='" + textrole.Text + "',Mobile='" + textmobile.Text + "',Address='" + textaddress.Text + "',Division='" + textdivision.Text + "' where User_ID='" + userid + "'", con);
                        cdm.ExecuteNonQuery();
                        GdVwUser.EditIndex = -1;
                        lblmsg.Visible = true;
                        lblmsg.ForeColor = Color.Green;
                        lblmsg.Text = "Update Secsussfully";
                    }
                    else
                    {
                        lblmsg.Visible = true;
                        lblmsg.ForeColor = Color.Red;
                        lblmsg.Text = "Division or Role Name is not Correct...";
                    }

                    con.Close();
                }
                catch(Exception)
                {
                    lblmsg.Visible = true;
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "This User Already Registered";
                }
                    
            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
            }
            getUser();
        }
        protected void GdVwUser_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try{
                int Did = int.Parse((Session["User_ID"]).ToString());
                int id = Convert.ToInt32(GdVwUser.DataKeys[e.RowIndex].Value.ToString());
                if (Did != id)
                {
                    SqlConnection conn = new SqlConnection(conString);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("delete FROM UserInfo where User_ID='" + id + "'", conn);
                    cmd.ExecuteNonQuery();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Deleted Secsussfully";
                    conn.Close();
                    getUser();
                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Sorry... This user Already Login";
                }
             }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
            }
            getUser();
        }
        protected void GdVwUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GdVwUser.PageIndex = e.NewPageIndex;
            getUser();
        }
        protected void GdVwUser_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GdVwUser.EditIndex = -1;
            getUser();
        }
       
        protected void btnpdf_Click(object sender, EventArgs e)
        {
                SqlConnection con = new SqlConnection(conString);
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GdVwUser.Rows[row.RowIndex].Cells[0].Text;
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM UserInfo where User_ID='" + Convert.ToInt32(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                string name = reader["FullName"].ToString();
                string email = reader["UserName"].ToString();
                string Role = reader["Role"].ToString();
                string Mobile = reader["Mobile"].ToString();
                string Address = reader["Address"].ToString();
                string Division = reader["Division"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Date"].ToString());
                string date = Birth.ToString("dd/MMM/yyyy");
                string Id = reader["User_ID"].ToString();
                reader.Close();
                con.Close();
                Document pdfDoc = new Document(PageSize.A4, 25, 10, 25, 10);
                var output = new MemoryStream();
                var writer = PdfWriter.GetInstance(pdfDoc, output);
                pdfDoc.Open();
                var titleFont = FontFactory.GetFont("Arial", 20, iTextSharp.text.BaseColor.BLUE);
                var apointFont = FontFactory.GetFont("Arial", 18, iTextSharp.text.BaseColor.GREEN);
                var boldTableFont = FontFactory.GetFont("Arial", 12, iTextSharp.text.Font.BOLD);
                var endingMessageFont = FontFactory.GetFont("Arial", 10, iTextSharp.text.Font.ITALIC);
                var bodyFont = FontFactory.GetFont("Arial", 12, iTextSharp.text.Font.NORMAL);
                pdfDoc.Add(new Paragraph("\n\n\nTo Whom It May Concern", titleFont));
                pdfDoc.Add(new Paragraph("\n\nAppointment Letter of ID : PGDICT20162070" + Id, apointFont));
                pdfDoc.Add(new Paragraph("\n\nDear All,\nThis is inform you that we have a new user in our office. \n\nNew User Information are given bellow :\n\n", endingMessageFont));
                var UserInfoTable = new PdfPTable(2);
                UserInfoTable.HorizontalAlignment = 0;
                UserInfoTable.SpacingBefore = 10;
                UserInfoTable.SpacingAfter = 10;
                UserInfoTable.DefaultCell.Border = 0;
                UserInfoTable.SetWidths(new int[] { 1, 4 });
                UserInfoTable.AddCell(new Phrase("Full Name :", boldTableFont));
                UserInfoTable.AddCell(name);
                UserInfoTable.AddCell(new Phrase("User Name :", boldTableFont));
                UserInfoTable.AddCell(email);
                UserInfoTable.AddCell(new Phrase("Joining Date :", boldTableFont));
                UserInfoTable.AddCell(date);
                UserInfoTable.AddCell(new Phrase("Role Type :", boldTableFont));
                UserInfoTable.AddCell(Role);
                UserInfoTable.AddCell(new Phrase("Mobile :", boldTableFont));
                UserInfoTable.AddCell(Mobile);
                UserInfoTable.AddCell(new Phrase("Address :", boldTableFont));
                UserInfoTable.AddCell(Address);
                UserInfoTable.AddCell(new Phrase("Division :", boldTableFont));
                UserInfoTable.AddCell(Division+"\n\n\n");
                pdfDoc.Add(UserInfoTable);
                pdfDoc.Add(new Paragraph("Please store this information for future inquiry.\n\n\nBest Regards\nAdmin\nBangladesh Computer Council", endingMessageFont));
                pdfDoc.Close();
                Response.ContentType = "application/pdf";
                Response.AddHeader("Content-Disposition", string.Format("attachment;filename=Appointment-{0}.pdf", name));
                Response.Buffer = true;
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite(output.ToArray());
                Response.End();
                Response.Close();        
        }



        protected void BtnUser_Click(object sender, EventArgs e)
        {
            PublicDivShow.Visible = false;
            MessageDivShow.Visible = false;
            NewsDivShow.Visible = false;
            theDiv.Visible = false;
            Newsdiv.Visible = false;
            getUser();

        }


        //----------------News Part-------------------------------
        protected void btnNews_Click(object sender, EventArgs e)
        {
            PublicDivShow.Visible = false;
            MessageDivShow.Visible = false;
            theDiv.Visible = false;
            UserDivShow.Visible = false;
            NewsDivShow.Visible = true;
            news();          
            
        }
        private void news()
        {

            try
            {

                SqlConnection con = new SqlConnection(conString);
                DataTable dt = new DataTable();
                SqlDataAdapter adapt = new SqlDataAdapter("SELECT * FROM LatestNews", con);
                con.Open();
                adapt.Fill(dt);
                con.Close();
                lblnumbercount.Text = (dt.Rows.Count).ToString();
                if (dt.Rows.Count > 0)
                {
                    GridViewNews.DataSource = dt;
                    GridViewNews.DataBind();
                    GridViewNews.Visible = true;
                    NewsDivShow.Visible = true;
                    divlblpub.Visible = false;
                    divlblmsg.Visible = true;

                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No Records Found";
                    GridViewNews.Visible = false;

                }

            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
                
            }
        }
       protected void btneditNews_Click(object sender, EventArgs e)
        {
            try
            {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            string mid = GridViewNews.Rows[row.RowIndex].Cells[1].Text;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM LatestNews where ID='" + Convert.ToInt32(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                txtnewsId.Text = reader["ID"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Date"].ToString());
                txtDates.Text = Birth.ToString("dd-MMM-yyyy");
                txtNews.Text = reader["News"].ToString();
                reader.Close();
                con.Close();
                Newsdiv.Visible = true;


            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Something wrong";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;

            }

        }
        protected void btnnewssave_Click(object sender, EventArgs e)
        {
            try {
                int newsid = int.Parse(txtnewsId.Text);
            DateTime dat = Convert.ToDateTime(txtDates.Text);
            string nw = txtNews.Text;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("update LatestNews set News='" + nw + "',Date='" + dat + "' where ID='" + newsid + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Newsdiv.Visible = false;
            lblmsg.Visible = true;
            lblmsg.ForeColor = Color.Green;
            lblmsg.Text = "SuccessFully Updated..";
            news();
            
            }
            catch (Exception)
            {
                lblmsg.Visible = true;
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Wrong Input Format....";
                divlblpub.Visible = false;
                divlblmsg.Visible = false;
            }

        }

    }
}