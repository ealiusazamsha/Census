﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.LoginPage
{
    public partial class Welcome : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        SqlDataAdapter adapt;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["FullName"] != null)
            {
                menushow();
                msgcount();
            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }
            if(!IsPostBack)
            {

                benner.Visible = true;
            }
            

        }

        private void menushow()
        {
            string name = (Session["FullName"]).ToString();
            string role = (Session["Role"]).ToString();
            lblwelcome.Text = (role + "| Welcome : " + name);

            if (role == "Manager")
            {
                UserMenu.Visible = false;
            }
            else if (role == "User")
            {
                UserMenu.Visible = false;
            }
            else
            {

            }
        }
        private void msgcount()
        {
            string uname = (Session["UserName"]).ToString();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand sqlcmd = new SqlCommand();
            con.Open();
            SqlCommand com = new SqlCommand("select sum(Number) as Total FROM Registration", con);
            SqlDataAdapter adt = new SqlDataAdapter("select Public_ID from Registration", con);
            DataTable cont = new DataTable();
            adt.Fill(cont);
            lblfmy.Text = (cont.Rows.Count).ToString();
            SqlDataReader reader = com.ExecuteReader();
            reader.Read();
            lbltotal.Text = reader["Total"].ToString();
            reader.Close();
            adapt = new SqlDataAdapter("select Id from Email where Status = 0 and Receiver = '" + uname + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            con.Close();
            lblmsgcount.Text = (dt.Rows.Count).ToString();
        }

        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("~/WebPage/Login.aspx");
        }
        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            getsent();
            benner.Visible = false;
            showgd.Visible = false;
            Divsnd.Visible = false;
            Sendmsg.Visible = false;
            details.Visible = false;

        }
        private void getsent()
        {

            try
            {
                string name = (Session["UserName"]).ToString();
                SqlConnection con = new SqlConnection(conString);
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT Id, Sub, Receiver, Attach, Time  FROM SendMessage where Sender ='" + name + "'", con);
                con.Open();
                adapt.Fill(dt);
                con.Close();
                Lsend.Text = (dt.Rows.Count).ToString();
                if (dt.Rows.Count > 0)
                {
                    GridViewsend.DataSource = dt;
                    GridViewsend.DataBind();
                    GridViewsend.Visible = true;
                    DivSendmsg.Visible = true;
                }
                else
                {
                    DivSendmsg.Visible = true;
                    Lsend.Text = "0";
                    GridViewsend.Visible = false;
                }

            }
            catch (Exception)
            {
                DivSendmsg.Visible = true;
                Lsend.Text = "Something wrong";

            }
        }
        protected void btnsendView_Click(object sender, EventArgs e)
        {
            try
            {
                benner.Visible = false;
                showgd.Visible = false;
                Sendmsg.Visible = false;
                details.Visible = false;
                DivSendmsg.Visible = true;
                Divsnd.Visible = true;
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewsend.Rows[row.RowIndex].Cells[0].Text;
                Session["send_ID"] = mid;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM SendMessage where Id='" + Convert.ToInt32(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                Lsrname.Text = reader["Receiver"].ToString();
                Lssub.Text = reader["Sub"].ToString();
                Lsmsg.Text = reader["Message"].ToString();
                Lssname.Text = reader["Sender"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Time"].ToString());
                Lstime.Text = Birth.ToString("hh:mm:ss tt   dd MMM, yyyy");
                string attach = reader["Attach"].ToString();
                reader.Close();
                con.Close();
                Divsnd.Visible = true;
                if (attach == "Yes") { Div2.Visible = true; }
                else { Div2.Visible = false; }
            }
            catch (Exception)
            {
                DivSendmsg.Visible = true;
                Lsend.Text = "Something wrong";

            }
        }
        protected void Btnsdown_Click(object sender, EventArgs e)
        {
            string mid = (Session["send_ID"]).ToString();
            byte[] bytes;
            string fileName, contentType;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name, Data, ContentType from SendMessage where Id='" + Convert.ToInt32(mid) + "'", con);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            bytes = (byte[])sdr["Data"];
            contentType = sdr["ContentType"].ToString();
            fileName = sdr["Name"].ToString();
            con.Close();
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }


        protected void btnsendreply_Click(object sender, EventArgs e)
        {
            try
            {

                benner.Visible = false;
                showgd.Visible = false;
                Sendmsg.Visible = true;
                details.Visible = false;
                DivSendmsg.Visible = false;
                Divsnd.Visible = false;
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewsend.Rows[row.RowIndex].Cells[0].Text;
                SqlConnection con = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                con.Open();
                SqlCommand com = new SqlCommand("select Sub, Receiver FROM SendMessage where Id='" + int.Parse(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                txtto.Text = reader["Receiver"].ToString();
                txtsub.Text = ("RE : ") + (reader["Sub"].ToString());
                txtto.Enabled = false;
                reader.Close();
                con.Close();
                txtmessage.Text = null;
                lblsendmsg.Text = "";
            }
            catch (Exception)
            {
                DivSendmsg.Visible = true;
                Lsend.Text = "Worng Input...!";
            }
        }
        protected void btnsendfor_Click(object sender, EventArgs e)
        {
            try
            {
                txtto.Enabled = true;
                benner.Visible = false;
                showgd.Visible = false;
                Sendmsg.Visible = true;
                details.Visible = false;
                DivSendmsg.Visible = false;
                Divsnd.Visible = false;
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewsend.Rows[row.RowIndex].Cells[0].Text;
                SqlConnection con = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM SendMessage where Id='" + int.Parse(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                string receiver = reader["Receiver"].ToString();
                string subj = reader["Sub"].ToString();
                string msg = reader["Message"].ToString();
                string name = reader["Sender"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Time"].ToString());
                string tt = Birth.ToString("hh:mm:ss tt   dd MMM, yyyy");
                txtsub.Text = ("FW : ") + (reader["Sub"].ToString());
                reader.Close();
                con.Close();
                txtto.Text = null;
                lblsendmsg.Text = "";
                txtmessage.Text = (("-----Original Message-----\n") + ("To : " + receiver + "\n") + ("From: " + name + "\n") + ("Sent Time: " + tt + "\n") + ("Subject: " + subj + "\n") + ("\n\n" + msg));

            }
            catch (Exception)
            {
                DivSendmsg.Visible = true;
                Lsend.Text = "Worng Input...!";
            }
        }

        protected void btnsendDel_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            string mid = GridViewsend.Rows[row.RowIndex].Cells[0].Text;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("delete from SendMessage where Id='" + int.Parse(mid) + "'", con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            getsent();
            benner.Visible = false;
            showgd.Visible = false;
            Sendmsg.Visible = false;
            details.Visible = false;
            Divsnd.Visible = false;
        }


        protected void BtnInbox_Click(object sender, EventArgs e)
        {
            benner.Visible = false;
            Sendmsg.Visible = false;
            details.Visible = false;
            DivSendmsg.Visible = false;
            Divsnd.Visible = false;
            getinbox();
        }
        private void getinbox()
        {

            try
            {
                string name = (Session["UserName"]).ToString();
                SqlConnection con = new SqlConnection(conString);
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT Id, Sub, Sender, Attach, Time  FROM Email where Receiver ='" + name + "'", con);                             
                con.Open();
                adapt.Fill(dt);
                con.Close();
                lblinnotis.Text = (dt.Rows.Count).ToString();
                if (dt.Rows.Count > 0)
                {
                    GridViewMail.DataSource = dt;
                    GridViewMail.DataBind();
                    GridViewMail.Visible = true;
                    showgd.Visible = true;
                }
                else
                {
                    lblinnotis.Text = "0";
                    showgd.Visible = true;
                    GridViewMail.Visible = false;
                }

            }
            catch (Exception)
            {
                showgd.Visible = true;
                lblinnotis.Text = "Something wrong";

            }
        }
        protected void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                benner.Visible = false;
                showgd.Visible = true;
                Sendmsg.Visible = false;
                details.Visible = true;
                DivSendmsg.Visible = false;
                Divsnd.Visible = false;
                int i = 1;
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewMail.Rows[row.RowIndex].Cells[0].Text;
                Session["message_ID"] = mid;
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand cmd = new SqlCommand("update Email set Status='" + i + "' where Id='" + Convert.ToInt32(mid) + "'", con);
                cmd.ExecuteNonQuery();
                SqlCommand com = new SqlCommand("select * FROM Email where Id='" + Convert.ToInt32(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                lblreceive.Text = reader["Receiver"].ToString();
                Lblsub.Text = reader["Sub"].ToString();
                LblMessage.Text = reader["Message"].ToString();
                Lblsendname.Text = reader["Sender"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Time"].ToString());
                lvltimes.Text = Birth.ToString("hh:mm:ss tt   dd MMM, yyyy");
                string attach = reader["Attach"].ToString();
                reader.Close();
                con.Close();
                details.Visible = true;
                if(attach == "Yes") { downloadDiv.Visible = true;}
                else { downloadDiv.Visible = false; }
            }
            catch (Exception)
            {
                lbldeltailsmsg.Visible = true;
                lbldeltailsmsg.Text = "Something wrong";

            }
        }
        protected void DownloadFile(object sender, EventArgs e)
        {
            string mid = (Session["message_ID"]).ToString();
            byte[] bytes;
            string fileName, contentType;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select Name, Data, ContentType from Email where Id='" + Convert.ToInt32(mid) + "'", con);
            SqlDataReader sdr = cmd.ExecuteReader();            
            sdr.Read();
            bytes = (byte[])sdr["Data"];
            contentType = sdr["ContentType"].ToString();
            fileName = sdr["Name"].ToString();
            con.Close();
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }


        protected void btnreply_Click(object sender, EventArgs e)
        {
            
            try
            {
                benner.Visible = false;
            showgd.Visible = false;
            Sendmsg.Visible = true;
            details.Visible = false;
            DivSendmsg.Visible = false;
            Divsnd.Visible = false;
                string name = (Session["UserName"]).ToString();
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewMail.Rows[row.RowIndex].Cells[0].Text;
                SqlConnection con = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                con.Open();
                SqlCommand com = new SqlCommand("select Sub, Sender FROM Email where Id='" + int.Parse(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                txtto.Text = reader["Sender"].ToString();
                txtsub.Text = ("RE : ") + (reader["Sub"].ToString());
                txtto.Enabled = false;
                reader.Close();
                con.Close();
                txtmessage.Text = null;
                lblsendmsg.Text = "";
            }
            catch (Exception)
            {
                showgd.Visible = true;
                lblinnotis.Text = "Worng Input...!";
            }
        }
        protected void btnfor_Click(object sender, EventArgs e)
        {
            try
            {
                txtto.Enabled = true;
                benner.Visible = false;
                showgd.Visible = false;
                Sendmsg.Visible = true;
                details.Visible = false;
                DivSendmsg.Visible = false;
                Divsnd.Visible = false;
                string name = (Session["UserName"]).ToString();
                Button btn = (Button)sender;
                GridViewRow row = (GridViewRow)btn.NamingContainer;
                string mid = GridViewMail.Rows[row.RowIndex].Cells[0].Text;
                SqlConnection con = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                con.Open();
                SqlCommand com = new SqlCommand("select * FROM Email where Id='" + int.Parse(mid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                string sendername = reader["Receiver"].ToString();
                string subj = reader["Sub"].ToString();
                string msg = reader["Message"].ToString();
                string receiver = reader["Sender"].ToString();
                DateTime Birth = Convert.ToDateTime(reader["Time"].ToString());
                string tt = Birth.ToString("hh:mm:ss tt   dd MMM, yyyy");
                txtsub.Text = ("FW : ") + (reader["Sub"].ToString());
                reader.Close();
                con.Close();
                txtto.Text = null;
                lblsendmsg.Text = "";
                txtmessage.Text = (("-----Original Message-----\n") + ("From : " + receiver  + "\n") + ("To: " + sendername + "\n") + ("Sent Time: " + tt + "\n") + ("Subject: " + subj + "\n") + ("\n\n" + msg));

            }
            catch (Exception)
            {
                showgd.Visible = true;
                lblinnotis.Text = "Worng Input...!";
            }
        }

        protected void btnDel_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            string mid = GridViewMail.Rows[row.RowIndex].Cells[0].Text;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand("delete from Email where Id='" + int.Parse(mid) + "'", con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            getinbox();
            benner.Visible = false;
            Sendmsg.Visible = false;
            details.Visible = false;
            DivSendmsg.Visible = false;
            Divsnd.Visible = false;
        }


        protected void BtnSendmsg_Click(object sender, EventArgs e)
        {
            benner.Visible = false;
            showgd.Visible = false;
            Sendmsg.Visible = true;
            details.Visible = false;
            DivSendmsg.Visible = false;
            Divsnd.Visible = false;
            txtto.Text = null;
            txtsub.Text = null;
            txtmessage.Text = null;
            txtto.Enabled = true;
            lblsendmsg.Visible = false;
        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
            inbox();
            Sendmail();
        }
        private void inbox()
        {
            string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection conn = null;
            try
            {
                string name = (Session["UserName"]).ToString();
                conn = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                conn.Open();
                SqlDataAdapter sqlda = new SqlDataAdapter("select UserName FROM UserInfo where UserName = '" + txtto.Text + "'", conn);           
                DataTable  dt = new DataTable();
                sqlda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                     string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                     string contentType = FileUpload1.PostedFile.ContentType;
                     if (filename != "")
                             {
                     using (Stream fs = FileUpload1.PostedFile.InputStream)
                     {
                         using (BinaryReader br = new BinaryReader(fs))
                         {
                             byte[] bytes = br.ReadBytes((Int32)fs.Length);                             
                                 sqlcmd.Connection = conn;
                                 sqlcmd.CommandType = CommandType.Text;
                                 sqlcmd.CommandText = "INSERT INTO [dbo].[Email]([Receiver],[Sub],[Message],[Sender],[Time],[Status],[Name],[ContentType],[Data],[Attach])VALUES(@Receiver, @Sub,@Message,@Sender,@Time,@Status,@Name,@ContentType,@Data,@Attach)";
                                 int i = 0;
                                 string a = "Yes";
                                 sqlcmd.Parameters.AddWithValue("@Receiver", txtto.Text);
                                 sqlcmd.Parameters.AddWithValue("@Sub", txtsub.Text);
                                 sqlcmd.Parameters.AddWithValue("@Message", txtmessage.Text);
                                 sqlcmd.Parameters.AddWithValue("@Sender", name);
                                 DateTime localDate = DateTime.Now;
                                 sqlcmd.Parameters.AddWithValue("@Time", localDate);
                                 sqlcmd.Parameters.AddWithValue("@Status", i);
                                 sqlcmd.Parameters.AddWithValue("@Name", filename);
                                 sqlcmd.Parameters.AddWithValue("@ContentType", contentType);
                                 sqlcmd.Parameters.AddWithValue("@Data", bytes);
                                 sqlcmd.Parameters.AddWithValue("@Attach", a);

                                 int flag = sqlcmd.ExecuteNonQuery();
                                 conn.Close();
                                 if (flag > 0)
                                 {
                                     lblsendmsg.Visible = true;
                                     lblsendmsg.Text = "Send Successfully";
                                 }
                                 else
                                 {
                                     lblsendmsg.Visible = true;
                                     lblsendmsg.Text = "Sorry somthing wrong.";
                                 }
                             }
                             
                         }
                     }
                    else
                    {
                        sqlcmd.Connection = conn;
                        sqlcmd.CommandType = CommandType.Text;
                        sqlcmd.CommandText = "INSERT INTO [dbo].[Email]([Receiver],[Sub],[Message],[Sender],[Time],[Status],[Attach])VALUES(@Receiver, @Sub,@Message,@Sender,@Time,@Status,@Attach)";
                        int i = 0;
                        string c = "No";
                        sqlcmd.Parameters.AddWithValue("@Receiver", txtto.Text);
                        sqlcmd.Parameters.AddWithValue("@Sub", txtsub.Text);
                        sqlcmd.Parameters.AddWithValue("@Message", txtmessage.Text);
                        sqlcmd.Parameters.AddWithValue("@Sender", name);
                        DateTime localDate = DateTime.Now;
                        sqlcmd.Parameters.AddWithValue("@Time", localDate);
                        sqlcmd.Parameters.AddWithValue("@Status", i);
                        sqlcmd.Parameters.AddWithValue("@Attach", c);

                        int flag = sqlcmd.ExecuteNonQuery();
                        conn.Close();
                        if (flag > 0)
                        {
                            lblsendmsg.Visible = true;
                            lblsendmsg.Text = "Send Successfully";
                        }
                        else
                        {
                            lblsendmsg.Visible = true;
                            lblsendmsg.Text = "Sorry somthing wrong.";
                        }
                    }
                
                }
                else
                {
                    lblsendmsg.Visible = true;
                    lblsendmsg.Text = "Sorry Your To Name is Wrong...";
                }


            }
            catch (Exception)
            {
                lblsendmsg.Visible = true;
                lblsendmsg.Text = "Worng Input...!";
            }


        }
        private void Sendmail()
        {
            string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection conn = null;
            try
            {
                string name = (Session["UserName"]).ToString();
                conn = new SqlConnection(conString);
                SqlCommand sqlcmd = new SqlCommand();
                conn.Open();
                SqlDataAdapter sqlda = new SqlDataAdapter("select UserName FROM UserInfo where UserName = '" + txtto.Text + "'", conn);
                DataTable dt = new DataTable();
                sqlda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    string contentType = FileUpload1.PostedFile.ContentType;
                    if (filename != "")
                    {
                        using (Stream fs = FileUpload1.PostedFile.InputStream)
                        {
                            using (BinaryReader br = new BinaryReader(fs))
                            {
                                byte[] bytes = br.ReadBytes((Int32)fs.Length);
                                sqlcmd.Connection = conn;
                                sqlcmd.CommandType = CommandType.Text;
                                sqlcmd.CommandText = "INSERT INTO [dbo].[SendMessage]([Receiver],[Sub],[Message],[Sender],[Time],[Name],[ContentType],[Data],[Attach])VALUES(@Receiver, @Sub,@Message,@Sender,@Time,@Name,@ContentType,@Data,@Attach)";
                                string a = "Yes";
                                sqlcmd.Parameters.AddWithValue("@Receiver", txtto.Text);
                                sqlcmd.Parameters.AddWithValue("@Sub", txtsub.Text);
                                sqlcmd.Parameters.AddWithValue("@Message", txtmessage.Text);
                                sqlcmd.Parameters.AddWithValue("@Sender", name);
                                DateTime localDate = DateTime.Now;
                                sqlcmd.Parameters.AddWithValue("@Time", localDate);
                                sqlcmd.Parameters.AddWithValue("@Name", filename);
                                sqlcmd.Parameters.AddWithValue("@ContentType", contentType);
                                sqlcmd.Parameters.AddWithValue("@Data", bytes);
                                sqlcmd.Parameters.AddWithValue("@Attach", a);

                                int flag = sqlcmd.ExecuteNonQuery();
                                conn.Close();
                                if (flag > 0)
                                {
                                    lblsendmsg.Visible = true;
                                    lblsendmsg.Text = "Send Successfully";
                                    txtto.Text = null;
                                    txtsub.Text = null;
                                    txtmessage.Text = null;
                                    txtto.Enabled = true;
                                }
                                else
                                {
                                    lblsendmsg.Visible = true;
                                    lblsendmsg.Text = "Sorry somthing wrong.";
                                }
                            }

                        }
                    }
                    else
                    {
                        sqlcmd.Connection = conn;
                        sqlcmd.CommandType = CommandType.Text;
                        sqlcmd.CommandText = "INSERT INTO [dbo].[SendMessage]([Receiver],[Sub],[Message],[Sender],[Time],[Attach])VALUES(@Receiver, @Sub,@Message,@Sender,@Time,@Attach)";
                        string c = "No";
                        sqlcmd.Parameters.AddWithValue("@Receiver", txtto.Text);
                        sqlcmd.Parameters.AddWithValue("@Sub", txtsub.Text);
                        sqlcmd.Parameters.AddWithValue("@Message", txtmessage.Text);
                        sqlcmd.Parameters.AddWithValue("@Sender", name);
                        DateTime localDate = DateTime.Now;
                        sqlcmd.Parameters.AddWithValue("@Time", localDate);
                        sqlcmd.Parameters.AddWithValue("@Attach", c);

                        int flag = sqlcmd.ExecuteNonQuery();
                        conn.Close();
                        if (flag > 0)
                        {
                            lblsendmsg.Visible = true;
                            lblsendmsg.Text = "Send Successfully";
                            txtto.Text = null;
                            txtsub.Text = null;
                            txtmessage.Text = null;
                            txtto.Enabled = true;
                        }
                        else
                        {
                            lblsendmsg.Visible = true;
                            lblsendmsg.Text = "Sorry somthing wrong.";
                        }
                    }

                }
                else
                {
                    lblsendmsg.Visible = true;
                    lblsendmsg.Text = "Sorry Your To Name is Wrong...";
                }


            }
            catch (Exception)
            {
                lblsendmsg.Visible = true;
                lblsendmsg.Text = "Worng Input...!";
            }


        }




    }
}