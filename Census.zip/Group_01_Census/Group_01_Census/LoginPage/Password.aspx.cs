﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.WebPage
{
    public partial class Password : System.Web.UI.Page
    {


        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            lblpass.Visible = false;
            if (Session["FullName"] != null)
            {
                menushow();
            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }
        }

        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("~/WebPage/Login.aspx");
        }

        private void menushow()
        {
            string name = (Session["FullName"]).ToString();
            string role = (Session["Role"]).ToString();
            lblwelcome.Text = (role + "| Welcome : " + name);

            if (role == "Manager")
            {
                UserMenu.Visible = false;
            }
            else if (role == "User")
            {
                UserMenu.Visible = false;
            }
            else
            {

            }
        }
        protected void btnpasschange_Click(object sender, EventArgs e)
        {
            passinfo();
        }
        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtoriginal.Text = null;
            txtnewpass.Text = null;
            txtconfirm.Text = null;
            lblpass.Visible = false;
        }
        private void passinfo()
        {
            string Pid = (Session["User_ID"]).ToString();

            try
            {

                SqlConnection con = new SqlConnection(conString);
                con.Open();
                SqlCommand com = new SqlCommand("select Password from UserInfo where User_ID='" + Convert.ToInt32(Pid) + "'", con);
                SqlDataReader reader = com.ExecuteReader();
                reader.Read();
                string passkey = reader["Password"].ToString();
                reader.Close();
                con.Close();
                string orginal = txtoriginal.Text;
                string newpss = txtnewpass.Text;
                string samepass = txtconfirm.Text;
                if (orginal == passkey)
                {
                    if (newpss == samepass)
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("update UserInfo set Password='" + newpss + "' where User_ID='" + Convert.ToInt32(Pid) + "'", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        lblpass.Visible = true;
                        lblpass.ForeColor = Color.Green;
                        lblpass.Text = " Successfully Changed your password...";
                    }
                    else
                    {
                        lblpass.Visible = true;
                        lblpass.ForeColor = Color.Red;
                        lblpass.Text = " New and Confirm Password Does not match...";
                    }
                }
                else
                {
                    lblpass.Visible = true;
                    lblpass.ForeColor = Color.Red;
                    lblpass.Text = " Original Password Does not match...";
                }

            }
            catch (Exception)
            {
                lblpass.Visible = true;
                lblpass.ForeColor = Color.Red;
                lblpass.Text = " Something Wrong...";
            }
        }


    }
}