﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.WebPage
{
    public partial class Update : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
       private int Pid;
        private void Page_Load(object sender, System.EventArgs e)
        {
            if (Session["FullName"] != null)
            {
                string name = (Session["FullName"]).ToString();
                string role = (Session["Role"]).ToString();
                lblwelcome.Text = (role + "| Welcome : " + name);
                if (role == "Manager" || role == "User")
                {
                    txtdiv.Enabled = false;
                }

            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }

        
            if(Request.QueryString["Id"] != null)
            { 
            string uid = Request.QueryString["Id"];
            Pid = int.Parse(uid);
            if (!IsPostBack)
            {
                databind();
            }
            }
            else
            {
                Response.Redirect("View.aspx");
            }
        }
        private void databind()
        {
            
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand com = new SqlCommand("select * FROM Registration where Public_ID='" + Pid + "'", con);
            SqlDataReader reader = com.ExecuteReader();
            reader.Read();
            txtname.Text = reader["Name"].ToString();
            txtfather.Text = reader["Father"].ToString();
            txtmother.Text = reader["Mother"].ToString();
            txtgender.Text = reader["Gender"].ToString();
            txtmobile.Text = reader["Mobile"].ToString();
            txtnid.Text = reader["NID"].ToString();
            txtnumber.Text = reader["Number"].ToString();
            DateTime Birth = Convert.ToDateTime(reader["DOB"].ToString());
            txtdob.Text = Birth.ToString("dd/MMM/yyyy");
            txtadd.Text = reader["Address"].ToString();
            txtupa.Text = reader["Upazila"].ToString();
            txtdist.Text = reader["District"].ToString();
            txtdiv.Text = reader["Division"].ToString();
            reader.Close();
            con.Close();
        }
       

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try {
                string division = (Session["Division"]).ToString();
                string role = (Session["Role"]).ToString();

                string uid = Request.QueryString["Id"];
                int Pid = int.Parse(uid);            
                string name = txtname.Text;
                string father = txtfather.Text;
                string mother = txtmother.Text;
                string gender = txtgender.Text;
                string mobile = txtmobile.Text;
                string nid = txtnid.Text;
                int number = int.Parse(txtnumber.Text);
                DateTime dob = Convert.ToDateTime(txtdob.Text);
                string add = txtadd.Text;
                string upa = txtupa.Text;
                string dist = txtdist.Text;
                string div = txtdiv.Text;
                string distn, d;
                d = div.ToLower();

                SqlConnection con = new SqlConnection(conString);
                con.Open();

                if (d=="barisal" || d=="chittagong" || d=="dhaka" || d=="khulna" || d=="mymensingh" || d=="rajshahi" || d=="rangpur" || d=="sylhet")
                {
                    if (role == "Manager" || role == "User")
                    {

                        SqlCommand divid = new SqlCommand("SELECT Division_ID FROM Division WHERE Division_Name ='" + txtdiv.Text + "'", con);
                        int did = (int)divid.ExecuteScalar();
                        SqlDataAdapter sqlda = new SqlDataAdapter("select * FROM District where Division_ID='" + did + "'and District_Name='" + txtdist.Text + "'", con);
                        DataTable dt = new DataTable();
                        sqlda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            distn = txtdist.Text;
                            SqlCommand cmd = new SqlCommand("update Registration set Name='" + name + "',Father='" + father + "',Mother='" + mother + "',Gender='" + gender + "',Mobile='" + mobile + "',NID='" + nid + "',Number='" + number + "',DOB='" + dob + "',Address='" + add + "',Upazila='" + upa + "',District='" + distn + "',Division='" + div + "' where Public_ID='" + Pid + "'", con);
                            cmd.ExecuteNonQuery();
                            con.Close();
                            Response.Redirect("View.aspx");
                        }
                        else
                        {
                            lblUpdatecMsg.Visible = true;
                            lblUpdatecMsg.ForeColor = Color.Red;
                            lblUpdatecMsg.Text = "District Name is not Correct...";

                        }
                    }
                    else
                    {
                        SqlCommand divid = new SqlCommand("SELECT Division_ID FROM Division WHERE Division_Name ='" + div + "'", con);
                        int did = (int)divid.ExecuteScalar();
                        SqlDataAdapter sqlda = new SqlDataAdapter("select * FROM District where Division_ID='" + did + "'and District_Name='" + txtdist.Text + "'", con);
                        DataTable dt = new DataTable();
                        sqlda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            distn = txtdist.Text;
                            SqlCommand cmd = new SqlCommand("update Registration set Name='" + name + "',Father='" + father + "',Mother='" + mother + "',Gender='" + gender + "',Mobile='" + mobile + "',NID='" + nid + "',Number='" + number + "',DOB='" + dob + "',Address='" + add + "',Upazila='" + upa + "',District='" + distn + "',Division='" + div + "' where Public_ID='" + Pid + "'", con);
                            cmd.ExecuteNonQuery();
                            con.Close();
                            Response.Redirect("View.aspx");
                        }
                        else
                        {
                            lblUpdatecMsg.Visible = true;
                            lblUpdatecMsg.ForeColor = Color.Red;
                            lblUpdatecMsg.Text = "District Name is not Correct...";
                        }

                    }
                }
                else
                {
                    lblUpdatecMsg.Visible = true;
                    lblUpdatecMsg.ForeColor = Color.Red;
                    lblUpdatecMsg.Text = "Division Name is not Correct...";
                }

                

               
            }
            catch(Exception)
            {
                throw;
                lblUpdatecMsg.Visible = true;
                lblUpdatecMsg.ForeColor = Color.Red;
                lblUpdatecMsg.Text = "Wrong Input Format....";
            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            databind();
        }
        protected void btnCancelupdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("View.aspx");
        }
    }
}