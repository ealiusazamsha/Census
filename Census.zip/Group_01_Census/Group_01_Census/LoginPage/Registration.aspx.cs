﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.WebPage
{
    public partial class Registration : System.Web.UI.Page
    {

        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        SqlConnection conn = null;
        SqlDataReader dr = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblPublicMsg.Visible = false;
            if (!this.IsPostBack)
            {
                publicreg();
            }
            if (Session["FullName"] != null)
            {
                menushow();
            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }

        }
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("~/WebPage/Login.aspx");
        }
        private void menushow()
        {
            string name = (Session["FullName"]).ToString();
           string role = (Session["Role"]).ToString();
            
            lblwelcome.Text = (role + "| Welcome : " + name);
            
            if (role == "Manager")
            {
                UserMenu.Visible = false;                
            }
            else if (role == "User")
            {
                UserMenu.Visible = false;              
            }
            else
            {

            }
        }

        private void publicreg()
        {
            try
            {
                string role = (Session["Role"]).ToString();
                string division = (Session["Division"]).ToString();
                conn = new SqlConnection(conString);
                conn.Open();
                if (role == "Manager" || role == "User")
                {

                    SqlCommand cmd = new SqlCommand("SELECT Division_ID, Division_Name FROM Division  where Division_Name ='" + division + "'", conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = conn;
                    ddlDiv.DataSource = cmd.ExecuteReader();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("SELECT Division_ID, Division_Name FROM Division");
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = conn;
                    ddlDiv.DataSource = cmd.ExecuteReader();
                }
                ddlDiv.DataValueField = "Division_ID";
                ddlDiv.DataTextField = "Division_Name";
                ddlDiv.DataBind();
                conn.Close();
                ddlDiv.Items.Insert(0, new ListItem("--Select Division--", "0"));
            }
            catch(Exception)
            {
                Session.RemoveAll();
                Response.Redirect("~/WebPage/Login.aspx");
            }
            
         }

        protected void ddlDiv_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn = new SqlConnection(conString);
            conString = "select * from District where Division_ID=" + ddlDiv.SelectedValue;
                SqlCommand cmd = new SqlCommand(conString, conn);
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                dr = cmd.ExecuteReader();

                ddlDist.DataSource = dr;
                ddlDist.DataTextField = "District_Name";
                ddlDist.DataValueField = "District_ID";
                ddlDist.DataBind();
                ddlDist.Items.Insert(0, new ListItem("--Select District--", "0"));

            if (conn.State != ConnectionState.Closed)
                conn.Close();
        }

        protected void ddlDist_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn = new SqlConnection(conString);
            conString = "select * from Upazila where District_ID=" + ddlDist.SelectedValue;
            SqlCommand cmd = new SqlCommand(conString, conn);

            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            dr = cmd.ExecuteReader();

            ddlUpazila.DataSource = dr;
            ddlUpazila.DataTextField = "Upazila_Name";
            ddlUpazila.DataBind();
            ddlUpazila.Items.Insert(0, new ListItem("--Select Upazilar--", "0"));

            if (conn.State != ConnectionState.Closed)
                conn.Close();
        } 


        protected void btnRegistration_Click(object sender, EventArgs e)
        {
            
            
            try
            {
                conn = new SqlConnection(conString);


                conn.Open();
                SqlCommand Nid = new SqlCommand("SELECT COUNT(*) FROM [Registration] WHERE ([NID] = @NID)", conn);
                SqlCommand Mob = new SqlCommand("SELECT COUNT(*) FROM [Registration] WHERE ([Mobile] = @Mobile)", conn);
                Nid.Parameters.AddWithValue("@NID", txtIDCard.Text);
                Mob.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                int NidExist = (int)Nid.ExecuteScalar();
                int MobExist = (int)Mob.ExecuteScalar();

                if (NidExist > 0 || MobExist > 0)
                {
                    lblPublicMsg.Visible = true;
                    lblPublicMsg.ForeColor = Color.Red;                    
                    lblPublicMsg.Text = "This Public Already Registered";
                    Clear();

                }
                else
                {

                    conn = new SqlConnection(conString);
                    SqlCommand sqlcmd = new SqlCommand();
                    conn.Open();
                    sqlcmd.Connection = conn;
                    sqlcmd.CommandType = CommandType.Text;

                    sqlcmd.CommandText = "INSERT INTO [dbo].[Registration]([Name],[Father],[Mother],[Gender],[Mobile],[NID],[Number],[DOB],[Division],[District],[Upazila],[Address])VALUES(@Name, @Father,@Mother,@Gender,@Mobile,@NID,@Number,@DOB,@Division,@District,@Upazila,@Address)";


                    sqlcmd.Parameters.AddWithValue("@Name", txtName.Text);
                    sqlcmd.Parameters.AddWithValue("@Father", txtFather.Text);
                    sqlcmd.Parameters.AddWithValue("@Mother", txtMother.Text);
                    if (rdoMale.Checked)
                        sqlcmd.Parameters.AddWithValue("@Gender", "Male");
                    else if (rdoFemale.Checked)
                        sqlcmd.Parameters.AddWithValue("@Gender", "Female");
                    else if (rdoOther.Checked)
                        sqlcmd.Parameters.AddWithValue("@Gender", "Others");
                    sqlcmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    sqlcmd.Parameters.AddWithValue("@NID", txtIDCard.Text);
                    sqlcmd.Parameters.AddWithValue("@Number", txtFamilyNumber.Text);
                    sqlcmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(TxtDOB.Text));
                    
                        conn = new SqlConnection(conString);
                        int j = Convert.ToInt32(ddlDiv.Text);
                        conn.Open();
                        conString = "select Division_Name from Division where Division_ID = '" + j + "'";
                        SqlCommand cmd = new SqlCommand(conString, conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        reader.Read();
                        string Div = reader["Division_Name"].ToString();
                        reader.Close();
                        conn.Close();
                        sqlcmd.Parameters.AddWithValue("@Division", Div);
                    
                    
                    int i = Convert.ToInt32(ddlDist.Text);
                    conn.Open();
                    conString = "select District_Name from District where District_ID = '" + i + "'";
                    SqlCommand com = new SqlCommand(conString, conn);
                    SqlDataReader r = com.ExecuteReader();
                    r.Read();
                    string Dist = r["District_Name"].ToString();
                    r.Close();
                    conn.Close();
                    
                    sqlcmd.Parameters.AddWithValue("@District", Dist);
                    sqlcmd.Parameters.AddWithValue("@Upazila", ddlUpazila.Text);
                    sqlcmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    int flag = sqlcmd.ExecuteNonQuery();
                    conn.Close();
                    if (flag > 0)
                    {
                        lblPublicMsg.Visible = true;
                        lblPublicMsg.ForeColor = Color.Green;
                        lblPublicMsg.Text = "Saved Successfully";
                        Clear();

                    }
                    else
                    {
                        lblPublicMsg.Visible = true;
                        lblPublicMsg.ForeColor = Color.Red;
                        lblPublicMsg.Text = "Sorry somthing worng.";
                    }

                }
            }
            catch (Exception)
            {
                lblPublicMsg.Visible = true;
                lblPublicMsg.ForeColor = Color.Red;
                lblPublicMsg.Text = "Worng Input...!";
                Clear();
            }
        }

        protected void btnRegistrationClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            txtName.Text = "";
            txtFather.Text = "";
            txtMother.Text = "";
            TxtDOB.Text = null;
            txtMobile.Text = "";
            txtIDCard.Text = "";
            txtFamilyNumber.Text = "";
            txtAddress.Text = "";
            ddlUpazila.Text = null;
            ddlDist.Text = null;
            ddlDiv.Text = null;
            rdoFemale.Checked = false;
            rdoMale.Checked = false;
            rdoOther.Checked = false;

        }
    }
}