﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.WebPage
{
    public partial class User : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        SqlConnection conn = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUserMsg.Visible = false;

            if (Session["FullName"] != null)
            {
                menushow();
            }
            else
            {
                Response.Redirect("~/WebPage/Login.aspx");
            }
            
        }
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("~/WebPage/Login.aspx");
        }
        private void menushow()
        {
            string name = (Session["FullName"]).ToString();
            string role = (Session["Role"]).ToString();
            lblwelcome.Text = (role + "| Welcome : " + name);

            if (role == "Manager")
            {
                UserMenu.Visible = false;
            }
            else if (role == "User")
            {
                ViewMenu.Visible = false;
                UserMenu.Visible = false;
            }
            else
            {

            }
        }


        protected void btnUserSignUp_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(conString);
                conn.Open();
                SqlCommand Uname = new SqlCommand("SELECT COUNT(*) FROM [UserInfo] WHERE ([UserName] = @UserName)", conn);
                SqlCommand UMob = new SqlCommand("SELECT COUNT(*) FROM [UserInfo] WHERE ([Mobile] = @Mobile)", conn);
                Uname.Parameters.AddWithValue("@UserName", txtuserName.Text);
                UMob.Parameters.AddWithValue("@Mobile", txtUserMobile.Text);
                int UnameExist = (int)Uname.ExecuteScalar();
                int UMobExist = (int)UMob.ExecuteScalar();

                if (UnameExist > 0 || UMobExist > 0)
                {
                    lblUserMsg.Visible = true;
                    lblUserMsg.ForeColor = Color.Red;
                    lblUserMsg.Text = "This Public Already Registered";
                    Clear();
                }
                else
                {
                    conn = new SqlConnection(conString);
                    SqlCommand sqlcmd = new SqlCommand();

                    conn.Open();
                    sqlcmd.Connection = conn;
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.CommandText = "INSERT INTO [dbo].[UserInfo]([FullName],[UserName],[Password],[Role],[Mobile],[Address],[Division],[Date])VALUES(@FullName, @UserName,@Password,@Role,@Mobile,@Address,@Division,@Date)";


                    sqlcmd.Parameters.AddWithValue("@FullName", txtUserFullName.Text);
                    sqlcmd.Parameters.AddWithValue("@UserName", txtuserName.Text.ToLower());
                    sqlcmd.Parameters.AddWithValue("@Password", txtUserpassword.Text);
                    sqlcmd.Parameters.AddWithValue("@Role", ddlUserRole.Text);
                    sqlcmd.Parameters.AddWithValue("@Mobile", txtUserMobile.Text);
                    sqlcmd.Parameters.AddWithValue("@Address", txtUserAddress.Text);
                    sqlcmd.Parameters.AddWithValue("@Division", ddlUserDivision.Text);
                    DateTime localDate = DateTime.Now;
                    sqlcmd.Parameters.AddWithValue("@Date", localDate);

                    int flag = sqlcmd.ExecuteNonQuery();
                    conn.Close();
                    if (flag > 0)
                    {
                        lblUserMsg.Visible = true;
                        lblUserMsg.ForeColor = Color.Green;
                        lblUserMsg.Text = "Saved Successfully";
                        Clear();

                    }
                    else
                    {
                        lblUserMsg.Visible = true;
                        lblUserMsg.ForeColor = Color.Red;
                        lblUserMsg.Text = "Sorry somthing worng.";
                    }


                }
            }
            catch (Exception)
            {
                lblUserMsg.Visible = true;
                lblUserMsg.ForeColor = Color.DarkRed;
                lblUserMsg.Text = "worng Input..!";
            }

        }
        private void Clear()
        {
            txtUserFullName.Text = "";
            txtuserName.Text = "";
            txtUserpassword.Text = "";
            ddlUserRole.Text = null;
            txtUserMobile.Text = "";
            txtUserAddress.Text = "";
            ddlUserDivision.Text = null;
        }

        protected void btnUserClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}