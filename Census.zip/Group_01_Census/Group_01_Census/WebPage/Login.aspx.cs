﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_01_Census.WebPage
{
    public partial class Login : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            lvlmsglogin.Visible = false;
        }
       
         protected void btnLogin_Click(object sender, EventArgs e)
        {
            int counter;
            if (ViewState["Count"] != null)
            {
                counter = Convert.ToInt32(ViewState["Count"]);
            }
            else
            {
                counter = 0;
            }
            counter = counter + 1;
            ViewState["Count"] = counter;

              do{
                SqlConnection con = new SqlConnection(conString);

                con.Open();

                SqlDataAdapter sqlda = new SqlDataAdapter("select * FROM UserInfo where UserName='" + txtLoginEmail.Text.ToLower() + "'and Password='" + txtLoginPassword.Text + "'", con);
                DataTable dt = new DataTable();
                sqlda.Fill(dt);
                con.Close();
                if (dt.Rows.Count == 1)
                {
                    string logid = dt.Rows[0]["User_ID"].ToString();
                    string usrnam = dt.Rows[0]["UserName"].ToString();
                    string Name = dt.Rows[0]["FullName"].ToString();
                    string role = dt.Rows[0]["Role"].ToString();
                    string division = dt.Rows[0]["Division"].ToString();

                    Session["User_ID"] = logid;
                    Session["UserName"] = usrnam;
                    Session["FullName"] = Name;
                    Session["Role"] = role;
                    Session["Division"] = division;

                    Response.Redirect("~/LoginPage/Welcome.aspx");
                }
                else
                {                    
                        lvlmsglogin.Visible = true;
                        lvlmsglogin.ForeColor = Color.Red;
                        lvlmsglogin.Text = "Invalid User Name or Password! Please try again!";
                        break;                    
                }
            } while (counter < 4) ;
              if (counter==3)
              { Response.Redirect("../Index.aspx"); }

            
         }
    }
}